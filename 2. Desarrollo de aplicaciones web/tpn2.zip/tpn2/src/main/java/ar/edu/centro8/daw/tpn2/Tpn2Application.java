package ar.edu.centro8.daw.tpn2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tpn2Application {

	public static void main(String[] args) {
		SpringApplication.run(Tpn2Application.class, args);
	}

}
